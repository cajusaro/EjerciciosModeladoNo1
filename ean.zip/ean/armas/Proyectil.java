package ean.armas;

public class Proyectil {

	private float velocidad;

	private float angulo;

}
