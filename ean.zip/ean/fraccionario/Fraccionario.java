package ean.fraccionario;

public class Fraccionario {

	private int numerador;

	private int denominador;

	public void Fraccionario() {

	}

	/**
	 *  
	 */
	public float darFraccionario(int numerador, int denominador) {
		return 0;
	}

	public void setNumerador(int numerador) {

	}

	public void setDenominador(int denominador) {

	}

}
