package ean.fecha;

public class Fecha {

	private int anno;

	private int mes;

	private int dia;

	public void setAnno(int anno) {

	}

	public void setMes(int mes) {

	}

	public void setDia(int dia) {

	}

}
