package ean.retail;

public class Producto {

	/**
	 * Tipo de producto
	 */
	private static final char LACTEO = "LACTEO";

	private static final char CARNICO = "CÁRNICO";

	private static final char FRUTA = "FRUTA";

	private static final char ENLATADO = "ENLATADO";

	/**
	 * Código del Producto
	 */
	private int codigo;

	/**
	 * Nombre del Producto
	 */
	private char nombre;

	/**
	 * Tipo del Producto (LACTEO, CÁRNICO, FRUTA, ENLATADO)
	 *  
	 */
	private char tipo;

	/**
	 * Fecha de Expiración (dd/mm/aaaa)
	 */
	private char fechaExp;

	/**
	 * NOmbre del Fabricante
	 */
	private int fabricante;

	/**
	 * Cantidad en Inventario
	 */
	private int stock;

	/**
	 * Precio Unitario
	 */
	private float precioUd;

	private Tienda tienda;

	/**
	 * Definición Constructor
	 */
	public void Producto() {

	}

}
