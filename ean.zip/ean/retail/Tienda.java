package ean.retail;

import java.util.Collection;

public class Tienda {

	private char nombreTienda;

	private char direccion;

	private char telefono;

	private Collection<Producto> producto;

	public void Tienda() {

	}

}
