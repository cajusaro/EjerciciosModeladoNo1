package ean.reloj;

public class Reloj {

	private int hora;

	private int minuto;

	private int segundo;

	public void Reloj() {

	}

	public void setHora(int hora) {

	}

	public void setMinuto(int minuto) {

	}

	public void setSegundo(int segundo) {

	}

}
