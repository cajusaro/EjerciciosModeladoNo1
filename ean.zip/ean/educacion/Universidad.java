package ean.educacion;

import java.util.Collection;

public class Universidad {

	private char nombreUniversidad;

	private char nombreRector;

	private int ciudad;

	private Collection<Factultad> factultad;

}
