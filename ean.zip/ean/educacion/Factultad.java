package ean.educacion;

import java.util.Collection;

public class Factultad {

	private char nombreFacultad;

	private Collection<Persona.Profesor> profesor;

	private Universidad universidad;

	private Collection<Persona.Estudiante> estudiante;

	private Collection<Carrera> carrera;

	private Collection<Curso> curso;

}
