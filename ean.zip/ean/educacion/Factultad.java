package ean.educacion;

import java.util.Collection;

public class Factultad {

	private char nombreFacultad;

	private Persona.Profesor profesor;

	private Persona.Estudiante estudiante;

	private Carrera carrera;

	private Curso curso;

	private Persona.Profesor profesor;

	private Collection<Persona.Profesor> profesor;

	private Universidad universidad;

	private Collection<Persona.Estudiante> estudiante;

	private Collection<Carrera> carrera;

	private Collection<Curso> curso;

}
