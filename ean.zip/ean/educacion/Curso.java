package ean.educacion;

import java.util.Collection;

public class Curso {

	private int codigoCurso;

	private char nombre;

	private int creditosCurso;

	private int salon;

	private Factultad factultad;

	private Persona.Profesor profesor;

	private Persona.Estudiante estudiante;

	private Collection<Carrera> carrera;
}
