package ean.educacion;

import java.util.Collection;

public class Curso {

	private int codigoCurso;

	private char nombre;

	private int creditosCurso;

	private int salon;

	private Factultad factultad;

	private Carrera carrera;

	private Persona.Profesor profesor;

	private Persona.Profesor profesor;

	private Persona.Estudiante estudiante;

	private Persona.Profesor profesor;

	private Carrera carrera;

	private Factultad factultad;

	private Collection<Carrera> carrera;

}
