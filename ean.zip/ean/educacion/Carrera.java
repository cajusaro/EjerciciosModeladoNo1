package ean.educacion;

import java.util.Collection;

public class Carrera {

	private static final char PREGRADO = "PREGRADO";

	private static final char POSTGRADO = "POSTGRADO";

	/**
	 * Nommbre de la Carrera
	 */
	private char nombreCarrera;

	/**
	 * Cantidad Creditos de la Carrera
	 */
	private int creditosCarrera;

	/**
	 * Cantidad Semetres de la carrera
	 */
	private int semestres;

	/**
	 * Nivel (PREGRADO, POSTGRADO)
	 */
	private char nivel;

	private Factultad factultad;

	private Curso curso;

	private Curso curso;

	private Factultad factultad;

	private Collection<Persona.Estudiante> estudiante;

	private Curso curso;

}
