package ean.educacion;

import java.util.Collection;

public abstract class Persona {

	private int cedula;

	private char nombre;

	private char fecNacimiento;

	private char lugNacimiento;

	public class Profesor extends Persona {

		private char profesion;

		private char nacionalidad;

		private double sueldo;

		private Factultad factultad;

		private Collection<Curso> curso;

	}

	public class Estudiante extends Persona {

		private int codigoEstudiante;

		private int semestreAct;

		private int fecIngreso;

		private Curso curso;

		private Factultad factultad;

		private Carrera carrera;

	}

}
