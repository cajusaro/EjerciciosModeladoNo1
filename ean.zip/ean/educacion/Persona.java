package ean.educacion;

import java.util.Collection;

public abstract class Persona {

	private int cedula;

	private char nombre;

	private char fecNacimiento;

	private char lugNacimiento;

	public class Profesor extends Persona {

		private char profesion;

		private char nacionalidad;

		private double sueldo;

		private Factultad factultad;

		private Factultad factultad;

		private Factultad factultad;

		private Curso curso;

		private Curso curso;

		private Collection<Curso> curso;

	}

	public class Estudiante extends Persona {

		private int codigoEstudiante;

		private int semestreAct;

		private int fecIngreso;

		private Factultad factultad;

		private Curso curso;

		private Factultad factultad;

		private Carrera carrera;

	}

}
